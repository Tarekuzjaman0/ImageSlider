<?php
// Set header for JSON response
header('Content-Type: application/json');

// Example image links (can be stored in a database or fetched from anywhere)
$imageLinks = [
    ["imageUrl" => "https://admissonjourney.xyz/PracticeApp/Image/one.jpeg"],
    ["imageUrl" => "https://admissonjourney.xyz/PracticeApp/Image/two.jpeg"],
       ["imageUrl" => "https://admissonjourney.xyz/PracticeApp/Image/panda.jpeg"],
          ["imageUrl" => "https://admissonjourney.xyz/PracticeApp/Image/red_panda.jpeg"],
    ["imageUrl" => "https://admissonjourney.xyz/PracticeApp/Image/three.jpeg"]
   
];

// Convert the array to JSON and return it
echo json_encode($imageLinks);
?>
